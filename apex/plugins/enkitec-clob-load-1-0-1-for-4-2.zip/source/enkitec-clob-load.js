;(function($){

'use strict';

$.widget('enkitec.clob_load', {
   options:{
      showModal: null,
      dialogTitle: null,
      loadingImageSrc: null,
      ajaxIdentifier: null,
      apexThis: null,
      pluginFilePrefix: null,
      apexImagePrefix: null
   },
   _create: function() {
      var uiw = this;

      uiw._createPrivateStorage();
      uiw._initElements();
   },
   _createPrivateStorage: function() {
      var uiw = this;

      uiw._values = {
         dialogCountData: 'clob_load_dialog_count'
      };

      uiw._elements = {
         $dialog: {}
      };
   },
   _initElements: function() {
      var uiw = this;

      uiw._elements.$dialog = $('div.clob-load-container');
   },
   _showDialog: function() {
      var uiw = this,
         dialogHtml;

      dialogHtml =
         '<div class="clob-load-container ui-widget">' +
         '   <img src="'+ uiw.options.loadingImageSrc  +'"/>' +
         '</div>';

      $('body').append(dialogHtml);

      uiw._initElements();

      uiw._elements.$dialog.dialog({
         disabled: false,
         autoOpen: true,
         closeOnEscape: false,
         dialogClass: 'clob-load-dialog',
         draggable: true,
         height: 'auto',
         hide: null,
         maxhHeight: false,
         maxWidth: false,
         minHeight: 100,
         minWidth: false,
         modal: true,
         resizable: false,
         show: null,
         stack: true,
         title: uiw.options.dialogTitle,
         close: function() {
            $(this).dialog('destroy');
            uiw._elements.$dialog.remove();
         }
      });

      uiw._initElements();
   },
   renderClob: function(opts) {
      var uiw = this,
         queryString,
         worker;

      if (uiw.options.showModal === 'Y') {
         uiw._incDialogCount();

         if (uiw._getDialogCount() === 1){
            uiw._showDialog();
         }
      }

      if (window.Worker) { //Web workers supported, move to background job
         worker = new Worker(uiw.options.pluginFilePrefix + 'enkitec-clob-load-worker.min.js');

         //Using native bindings as jQuery's causes problems with workers
         worker.addEventListener('message', function(e) {
            uiw._handleClobRenderSuccess(e.data.clob, opts.$elmt[0]);
         }, false);

         worker.postMessage({
            p_flow_id: $('#pFlowId').val(),
            p_flow_step_id: $('#pFlowStepId').val(),
            p_instance: $('#pInstance').val(),
            p_request: 'PLUGIN=' + opts.ajaxIdentifier,
            x01: 'RENDER_CLOB'
         });
      } else {
         queryString = {
            p_flow_id: $('#pFlowId').val(),
            p_flow_step_id: $('#pFlowStepId').val(),
            p_instance: $('#pInstance').val(),
            p_request: 'PLUGIN=' + opts.ajaxIdentifier,
            x01: 'RENDER_CLOB'
         };

         $.ajax({
            type: 'POST',
            url: 'wwv_flow.show',
            data: queryString,
            dateType: 'text',
            async: true,
            context: this,
            success: function(data){
               uiw._handleClobRenderSuccess(data, opts.$elmt[0]);
            }
         });
      }
   },
   _handleClobRenderSuccess: function(data, elmt) {
      var uiw = this;

      $s(elmt, data);
      $.data(elmt, 'defaultValue', data);

      if (uiw.options.showModal === 'Y') {
         uiw._decDialogCount();
      }

      if (uiw._getDialogCount() === 0) {
         if (!$.isEmptyObject(uiw._elements.$dialog)){
            uiw._elements.$dialog.dialog('close');
         }

         $(document).trigger('enkitecclobloadrendercomplete');
      }
   },
   submitClob: function(opts){
      var uiw = this,
         elmt,
         clobData,
         defaultValue,
         queryString,
         worker;

      elmt = opts.$elmt[0];
      clobData = $v(elmt);
      defaultValue = $.data(elmt, 'defaultValue');
      $s(elmt, ''); //added due to trouble submitting page, look into catching errors and putting values back

      if (opts.changeOnly === 'N' || clobData !== defaultValue) {
         if (uiw.options.showModal === 'Y') {
            uiw._incDialogCount();

            if (uiw._getDialogCount() === 1){
               uiw._showDialog();
            }
         }

         if (opts.makeBlocking === 'Y') {
            queryString = {
               p_flow_id: $('#pFlowId').val(),
               p_flow_step_id: $('#pFlowStepId').val(),
               p_instance: $('#pInstance').val(),
               p_request: 'PLUGIN=' + opts.ajaxIdentifier,
               x01: 'SUBMIT_CLOB',
               f01: []
            };

            queryString = uiw._chunkClob(clobData, 30000,  queryString);

            $.ajax({
               type: 'POST',
               url: 'wwv_flow.show',
               data: queryString,
               dateType: 'text',
               async: false,
               context: this,
               success: function(data){
                  uiw._handleSubmitClobSuccess();
               }
            });
         } else {
            if (window.Worker) { //Web workers supported, move to background job
               worker = new Worker(uiw.options.pluginFilePrefix + 'enkitec-clob-load-worker.min.js');

               //Using native bindings as jQuery's causes problems with workers
               worker.addEventListener('message', function(e) {
                  uiw._handleSubmitClobSuccess();
               }, false);

               worker.postMessage({
                  p_flow_id: $('#pFlowId').val(),
                  p_flow_step_id: $('#pFlowStepId').val(),
                  p_instance: $('#pInstance').val(),
                  p_request: 'PLUGIN=' + opts.ajaxIdentifier,
                  x01: 'SUBMIT_CLOB',
                  clobData: clobData
               });
            } else {
               queryString = {
                  p_flow_id: $('#pFlowId').val(),
                  p_flow_step_id: $('#pFlowStepId').val(),
                  p_instance: $('#pInstance').val(),
                  p_request: 'PLUGIN=' + opts.ajaxIdentifier,
                  x01: 'SUBMIT_CLOB',
                  f01: []
               };

               queryString = uiw._chunkClob(clobData, 30000,  queryString);

               $.ajax({
                  type: 'POST',
                  url: 'wwv_flow.show',
                  data: queryString,
                  dateType: 'text',
                  async: true,
                  context: this,
                  success: function(data){
                     uiw._handleSubmitClobSuccess();
                  }
               });
            }
         }
      }
   },
   _handleSubmitClobSuccess: function(){
      var uiw = this;

      if (uiw.options.showModal === 'Y') {
         uiw._decDialogCount();
      }

      if (uiw._getDialogCount() === 0) {
         if (!$.isEmptyObject(uiw._elements.$dialog)) {
            uiw._elements.$dialog.dialog('close');
         }

         $(document).trigger('enkitecclobloadsubmitcomplete');
      }
   },
   _incDialogCount: function(){
      var uiw = this,
         count = uiw._getDialogCount();

      if (count === undefined || count < 0) {
         count = 1;
         uiw._setDialogCount(count);
      } else {
         count++;
         uiw._setDialogCount(count);
      }
   },
   _decDialogCount: function(){
      var uiw = this,
         count = uiw._getDialogCount();

      if (count >= 0) {
         count--;
         uiw._setDialogCount(count);
      }
   },
   _getDialogCount: function(){
      var uiw = this,
         count = $.data(document, uiw._values.dialogCountData);

      return (count === undefined || count < 0) ? 0 : count;
   },
   _setDialogCount: function(newCount){
      var uiw = this;

      $.data(document, uiw._values.dialogCountData, newCount);
   },
   _chunkClob: function(clob,size,queryString){
      var uiw = this,
         loopCount = Math.floor(clob.length / size) + 1;

      for (var i = 0; i < loopCount; i++) {
         queryString.f01.push(clob.slice(size * i,size*(i+1)));
      }

      return queryString;
   }
});
})(apex.jQuery);